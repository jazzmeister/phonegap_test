//## ----------------- SHARED VIEWS

//## Backbone views have a horrible inheritance setup, so this is a quick hack to share rating / feedback functionality across answer views
var AnswerViewMixin = {
    addCommonEvents: function(view) {

        //## Question Rating (Stars) changed
        view.questionRatingChanged = function(event, rating) {
            appLib.log('rating changed to: ' + rating);

            var qid = $('.answerPage').data('qid');
            oe.setQuestionRating(qid, rating);
        };


        //## Question Feedback - scroll to show textbox when it receives focus
        view.scrollToFeedback = function() {
            $('#questionFeedbackGroup').css('padding-bottom', '400px');        
            window.scrollTo(0, $('#questionFeedbackHeader')[0].offsetTop - 40);
        };

        //## Question Feedback - save question feedback the user entered
        view.saveFeedback = function() {        
            var feedback = $('#questionFeedback').val();        
            var qid = $('.answerPage').data('qid');

            appLib.log('feedback: ' + feedback);
            oe.setQuestionFeedback(qid, feedback);

            if(appLib.getDevice() === 'android') {
                StatusBar.hide();            
            }
        };


        //## Bind events
        if(_.isUndefined(view.events)) {
            view.events = {};
        }

        view.delegateEvents(_.extend(view.events, {
            'star-rating:changed': 'questionRatingChanged',
            'focus #questionFeedback': 'scrollToFeedback',
            'focusout #questionFeedback': 'saveFeedback'        
        }));        
    }    
};





//## ----------------- VIEWS

//## Home
var HomeView = Backbone.View.extend({
    template: _.template(oeTemplate.get('HomeTemplate')),
	
    render: function(eventName) {
		var hideContinueSession = _.isUndefined(this.model) || this.model == null;		
		var continueSessionButtonStyle = (hideContinueSession ? 'display:none;' : '');
		
		var html = this.template({ buttonStyle: continueSessionButtonStyle });
        $(this.el).html(html);		
                                    
        return this;
    }
});




//========================================================================================

//## App Update
var AppUpdateView = Backbone.View.extend({
    template: _.template(oeTemplate.get('AppUpdateTemplate')),
	
    render: function(eventName) {				
        $(this.el).html(this.template());		
                                    
        return this;
    },
	
	events: {
		"click #appUpdate": "appUpdate"		
	},
	
	appUpdate: function() {
		appLib.openAppStore();
	}
});




//========================================================================================


//## Settings	
var SettingsView = Backbone.View.extend({
    template: _.template(oeTemplate.get('SettingsTemplate')),

    render: function(eventName) {		
		var sessionState = 'Session is not logged in';
		var sessionStyle = '';
		
		try {
			var sessionExpires = parseInt(oe.auth.get('tokenExpires').replace(/\/Date\((-?\d+)\)\//, '$1'));
			if(sessionExpires > new Date().getTime()) {
				sessionState = 'Session is logged in';
				sessionStyle = 'color:green;';
			} else {
				sessionState = 'Session login has expired';
				sessionStyle = 'color:red;';
			}
		} catch(e) { }
	
        $(this.el).html(this.template({ 
			version: oeConstants.version + (oe.isMinified() ? '' : ' <span style=\'color:red;\'>(Dev. Build)</span>'),
			sessionState: sessionState,
			sessionStyle: sessionStyle
		}));
        return this;
    },
	
	
	events: {
		"click #clearSignIn": "clearSignIn",
		"click #rateApp": "rateApp"
	},
	
	clearSignIn: function() {                                          
		var session = oe.currentSession();
	
		if(session != null && session.hasAnswersToUpload())
			appLib.confirm('You have answers to upload.\n\nAre you sure you wish to lose these answers and Log Out?',
							 this.clearSignInConfirmation,
							 'Log Out',
							 'Yes,No');
		else
			appLib.confirm('Are you sure you wish to Log Out?',
							 this.clearSignInConfirmation,
							 'Log Out',
							 'Yes,No');										 
	},
			
	
	clearSignInConfirmation: function(buttonIndex) {
		if(buttonIndex == 1) {
			//## Reset everything!
			oe.reset();
			
			appLib.alert('You have been Logged Out successfully', function() { app.trigger('home'); });
		}
	},
	
	rateApp: function() {
		appLib.rateApp(true);
	}
});


//========================================================================================

//## Terms & Conditions	
var TermsConditionsView = Backbone.View.extend({
    template: _.template(oeTemplate.get('TermsConditionsTemplate')),

    render: function(eventName) {		
        $(this.el).html(this.template());        
		
        return this;
    }
    
});



//========================================================================================

//## Privacy Policy	
var PrivacyPolicyView = Backbone.View.extend({
    template: _.template(oeTemplate.get('PrivacyPolicyTemplate')),

    render: function(eventName) {		
        $(this.el).html(this.template());        
		
        return this;
    }
    
});



//========================================================================================

//## Login	
var LoginView = Backbone.View.extend({
    template: _.template(oeTemplate.get('LoginTemplate')),

    render: function(eventName) {	
        var demoModeStyle = (oe.destination == null ? '' : 'display:none;');
                                     
        $(this.el).html(this.template({ demoModeStyle: demoModeStyle }));        
		
        return this;
    },
	
	
	events: {
		"click #login-button": "login"		
	},
	
	login: function() {
		var email = this.$('#email').val()
		var password = this.$('#password').val();		
		
		if(email.length == 0) {
			appLib.alert('Email cannot be blank!');
			return;
		}

		if(password.length == 0) {
			appLib.alert('Password cannot be blank!');
			return;
		}
		
		
		this.tryAuth(email, password);
	},	
	
	
	tryAuth: function(email, password) {
		var view = this;
			
		oe.ajax('AuthenticateUser', 
				{
					deviceId: appLib.getDeviceId(oeConstants.version),
					emailAddress: email,
					password: password
				},
				function(data, textStatus) { 
                    /*
                    appLib.log('success func');
                    appLib.log(data.d.AssessmentAPIToken);
                    appLib.log(data.d.AssessmentAPIToken.Token);
                    appLib.log(data.d.AssessmentAPIToken.UserId);
                    */
                
					if (!_.isUndefined(data.d) && !_.isUndefined(data.d.AssessmentAPIToken)) {						
						if(data.d.AssessmentAPIToken.Token != null) {												
							view.model.set('email', email);
							view.model.set('key', data.d.AssessmentAPIToken.Token);
							view.model.set('userId', data.d.AssessmentAPIToken.UserId);
							view.model.set('tokenExpires', data.d.AssessmentAPIToken.ExpiryDate);
							
                            //## Signal where to navigate to. Default to selecting exam, but can optionally be session review
                            var appEvent = 'selectExam';
                            if(oe.destination != null) {
                                appLib.log('destination is ' + oe.destination);
                                appEvent = oe.destination;
                                oe.destination = null;
                            }       
                
							app.trigger(appEvent);
						}
					}
				}, 
				function(data, msg, errorText) { 
                    if(errorText == null || errorText.length == 0)
						appLib.alert('Unable to access onExamination website');
					else if (!_.isUndefined(data) && !_.isUndefined(data.d) && !_.isUndefined(data.d.SuggestUpdate) && data.d.SuggestUpdate) {	
						oe.destination = null;
												
						app.trigger('appUpdate');
					} else
						appLib.alert(errorText);
                });

	}
});



//========================================================================================

//## Getting Started	
var GettingStartedView = Backbone.View.extend({
    template: _.template(oeTemplate.get('GettingStartedTemplate')),

    render: function(eventName) {		
        $(this.el).html(this.template());        
		
        return this;
    }
    
});


//========================================================================================

//## Demo page	
var DemoView = Backbone.View.extend({
    template: _.template(oeTemplate.get('DemoTemplate')),

    render: function(eventName) {		
        $(this.el).html(this.template());        
		
        return this;
    },
	
	
	events: {
		"click #startQuestions": "startQuestions"
	},	
	
	startQuestions: function() {		
		app.trigger('startDemoQuestions');
	}		
});


//========================================================================================

//## Exam page
var ExamView = Backbone.View.extend({
    template: _.template(oeTemplate.get('ExamSelectionTemplate')),

    render: function (eventName) {
        //## Get the user's exams
        oe.getUserExams(this, this.renderUserExams);

        $(this.el).html(this.template({ 
            selectExamButton: 'Select Revision Options',
            displayExamDateSection: appLib.cssDisplay(true) 
        }));

        return this;
    },

    renderUserExams: function (view, exams, currentExamId) {
        var options = _.map(exams, function (item) {
            return {
                id: item.ExamId,
                text: item.ExamName,
                selected: (item.ExamId == currentExamId),
                examDate: item.ExamDate                
            };
        });
		
        appLib.fillTemplatedDropDown('examList', options, 'data-examdate="<%= examDate %>"');
        view.updateExamDate();
    },


    events: {
        "change #examList": "changeExam",
        "click #selectExam": "selectExam",
		"click #selectExamDate": "editExamDate"
    },

    changeExam: function() {
        this.updateExamDate();
    },

    updateExamDate: function() {
        var selectedExam = $('#examList').find(':selected');
        $('#examDate').text('When is your ' + selectedExam.text() + ' exam?');

        var examDate = selectedExam.data('examdate');
        if(typeof examDate === 'undefined') {
            return;
        }
        
        try {
            var dt = new Date(parseInt(examDate.substr(6)));
            this.displayExamDate(dt);
        }  catch(ex) { }      
    },

    displayExamDate: function(d) {
        $('#examDate').text('Your ' + $('#examList').find(':selected').text() + ' exam is on ' + appLib.getFormattedDate(d));
    },

    selectExam: function () {
        var selectedExamId = $('#examList').val();

        if (selectedExamId == null) {
            appLib.alert('Please select an exam');
            return;
        }


        oe.selectedExamId = selectedExamId;
        app.trigger('selectRevisionType');
    },
	
	editExamDate: function() {
        var view = this;
		var examDate = $('#examDate').data('date');
		var dt = new Date();
		
		if(examDate !== '')
			dt = new Date(dt);
				
		appLib.selectDate({ 
			date: dt,
			mode: 'date'
		}, function(d) {
			if(typeof d !== 'undefined') {				
                oe.setUserExamDate($('#examList').find(':selected').val(), 
                                    d, 
                                    function() {
                                        view.displayExamDate(d);    

                                        //## Update exam date in exam drop down
                                        $('#examList').find(':selected').data('examdate', '/Date(' + d.getTime() + ')/');
                                    });
			}
		}, function(err) {
			//## Do nothing - user cancelled date dialog
		});
	}
});


//========================================================================================

//## Demo Exam page
var DemoExamView = Backbone.View.extend({
    template: _.template(oeTemplate.get('ExamSelectionTemplate')),

    render: function (eventName) {
        //## Get the demo exams
        oe.getDemoExams(this.renderDemoExams, this.renderLocalDemoExams);

        //## For testing without internet: 
        //_.delay(this.renderLocalDemoExams, 1000, this); 

        $(this.el).html(this.template({ 
            selectExamButton: 'Start Demo Questions', 
            displayExamDateSection: appLib.cssDisplay(false) 
        }));

        return this;
    },


    //## Successfully downloaded demo exams, save and display them
    renderDemoExams: function (exams) {
        var options = oe.convertExamListToDropDownFormat(exams);        

        appLib.log('Displaying API demo exams');
        appLib.sortAndFillDropDown('examList', options);
    },


    //## Use local demo data if internet is unavailable
    renderLocalDemoExams: function () {
        if (oe.demoExams == null || oe.demoExams.length == 0) {
            appLib.alert('An Internet connection is required to download all demo exams');

            //## Setup local MRCP Part 1 exam and questions
            oe.demoExams = [{ ExamId: oeConstants.mrcpPart1, ExamName: 'MRCP Part 1'}];
            oe.demoQuestions = [{ examId: oeConstants.mrcpPart1, updatedAt: 0, questions: null}];

            appLib.log('Local exams = local MRCP Part 1');
                                        
        } else {					
			//## Limit demoExams to exams that we have questions for
			var availableExams = _.filter(oe.demoExams, function(availableExam) {
				//## Do we have questions for this exam?
				var haveQuestions = false;
				
				_.each(oe.demoQuestions, function(exam) {
					if(exam.examId == availableExam.ExamId)
						haveQuestions = true;
				});
				
				return haveQuestions;
			});
                                        
            //## Add MRCP Part 1 if it's not been downloaded
            var containsMrcpPart1 = false;
			_.each(availableExams, function(exam) {
				 if(exam.ExamId == oeConstants.mrcpPart1)                                               
					containsMrcpPart1 = true;                                  
			});

			if(!containsMrcpPart1) {
				availableExams.push({
										ExamId: oeConstants.mrcpPart1,
										ExamName: 'MRCP Part 1'
									});
			
			   oe.demoQuestions.push({ examId: oeConstants.mrcpPart1, updatedAt: 0, questions: null});
			}
                                        
										
			appLib.log('filtering demo question list');
			oe.demoExams = availableExams;
		}

		
        var options = oe.convertExamListToDropDownFormat(oe.demoExams);

        appLib.log('Displaying local demo exams');
        appLib.sortAndFillDropDown('examList', options);
    },


    events: {
        "click #selectExam": "selectExam"
    },

    selectExam: function () {
        var selectedExamId = $('#examList').val();

        if (selectedExamId == null) {
            appLib.alert('Please select an exam');
            return;
        }


        //## Do we have any local demo questions for this exam?
        var demoExam = _.find(oe.demoQuestions, function (exam) {
            return (exam.examId == selectedExamId);
        });



        //## Function to download demo questions, and if successful save them locally, before starting to view the questions
        var downloadDemoQuestions = function (examId) {
                                        oe.getDemoQuestions(examId,
                                                            function (questions, updateDate) {
                                                                //## Store demo questions locally
                                                                oe.demoQuestions.push({
                                                                    examId: examId,
                                                                    questions: questions,
                                                                    updatedAt: updateDate
                                                                });

                                                                appLib.log('Starting downloaded demo questions for exam ' + examId);
                                                                app.trigger('startDemoQuestions');
                                                            },
                                                            function () {
                                                                appLib.alert('An Internet connection is required to download demo questions');
                                                            });
        };


        //## Function to setup and view local demo questions
        var startLocalDemoQuestions = function (demoExam) {
            appLib.log('Starting local demo questions for exam ' + demoExam.examId);            

            //## Load questions, but don't download images as we're offline
            oe.loadQuestions(demoExam.questions, 
                             demoExam.examId, 
                             false, 
                             function () {
                                app.trigger('startDemoQuestions');
                             },
                             jQuery.noop);
        };



        if (demoExam == null) {
            //## No local questions - download from API
            downloadDemoQuestions(selectedExamId);

        } else {

            //## Has the user selected local MRCP Part 1 demo?
            if (selectedExamId == oeConstants.mrcpPart1 && demoExam.questions == null) {
                oe.questionBank = demoQuestions;
                oe.assessmentId = null;

                appLib.log('Starting hardcoded demo question for MRCP Part 1');

                app.trigger('startDemoQuestions');
                return;
            }


            //## Local questions, but are they up-to-date?
            oe.getDemoLastChangeDate(selectedExamId,
                                     function (updatedAt) {
                                         if (demoExam.updatedAt != updatedAt) {
                                             //## New questions so remove demo exam from local demo list
                                             oe.demoQuestions = _.without(oe.demoQuestions, demoExam);

                                             appLib.log('Updating demo questions for exam ' + selectedExamId);

                                             //## Download new demo questions - and save to local demo list
                                             downloadDemoQuestions(selectedExamId);

                                         } else {
                                             //## No updates, so use current demo questions
                                             startLocalDemoQuestions(demoExam);
                                         }
                                     },
                                     function () {
                                         //## Error checking for question updates - so use local demo questions
                                         startLocalDemoQuestions(demoExam);
                                     });
        }
    }
});


//========================================================================================

//## Revision Type Selection
var RevisionTypeMenuView = Backbone.View.extend({
    template: _.template(oeTemplate.get('RevisionTypeTemplate')),

    render: function (eventName) {		        
        $(this.el).html(this.template());
        
		appLib.maskUI(true);
        _.delay(this.postRender, 1000, this);
                                                		
		return this;
    },

    postRender: function (context) {        		
		var getCurricula = function(resolve, reject) {
			appLib.log('getCurricula start');
			
			//## Download curricula and render the list
			oe.getCurricula(function(results) {
					context.renderCategoryList(results);
					
					appLib.log('getCurricula resolve');
					resolve();
				}, oe.selectedExamId);
		};
		
		var getQuestionTypes = function(resolve, reject) { 
			appLib.log('getQuestionTypes start');
		
			$.proxy(oe.getQuestionTypes, context, function(results) {
					context.renderQuestionTypeList(results);
					
					appLib.log('getQuestionTypes resolve');
					resolve();
				}, oe.selectedExamId).apply();        
		};				
		
		Promise.all([new Promise(getCurricula), new Promise(getQuestionTypes)])
			.then(function() {                                                		
				var options = oe.getRevisionOptions();
                
				if(options == null) {
					//## Work hard settings
					context.changeRevisionType();
					context.updateQuestionCount();
					
				} else {
					//## Shared settings
					if(!options.allQuestionTypes) {
						context.setQuestionTypes(options.questionTypes);                    
					}
										
					if(options.revisionType == 'WorkSmart') {
						//## Work smart specific settings
						$('#revisionType').val('WorkSmart').selectmenu('refresh');
						context.changeRevisionType(true);
						
						$('#showAnswerAfterQuestion').val(options.showAnswers ? 'true' : 'false').selectmenu('refresh');
						context.setDifficulty(options.difficulty.diff);
						context.setQuestionStatus(options.questionStatus);
						context.setCategoriesCSV(options.categoriesCSV);
											
						context.updateQuestionCount();
						
						//## Required if user changes to 'Work Hard' 
						context.updateWorkHardQuestionCount();                                                            
					
					} else {
						//## Work hard settings
						context.changeRevisionType();
						context.updateQuestionCount();
					}
				}
                
				appLib.maskUI(false);
				$('#revisionOptionsLoading').hide();
                $('#revisionOptions').show();                                                
				
			//## YUI Compressor doesn't validate promise .catch() syntax, so next line is equivalent to:
			//## }).catch(function(error) {
			}).then(undefined, function(error) {
				appLib.maskUI(false);
				
                //TODO: Retry promises?                
				appLib.alert('An error occurred');
			});                
    },


    events: {
        "click #startQuestions": "startQuestions",
        "change #revisionType": "changeRevisionType",
        "change #questionDifficulty": "showQuestionDifficulty",
        "change #questionCategory": "showQuestionCategories",
        "change #questionType": "updateQuestionTypes",
        "change #questionStatus": "changeQuestionStatus",

        //## Seems backbone uses 'live()' to bind events, so this works even though the checkboxes don't exist when the view is rendered!
        "change #questionCategoryList input[type='checkbox']": "updateWorkSmartQuestionCount",
        "change #questionTypeList input[type='checkbox']": "updateQuestionCount",
		
		"click #selectAllCats": "selectAllCats",
        "click #selectNoCats": "selectNoCats",
        "click #resetFilters": "resetFilters"
    },
    	   
	
    startQuestions: function () {
        //## Download required questions
		
		var options = {
			revisionType: $('#revisionType').val(),
			numberOfQuestions: $('#questionLimit').val(),
			difficulty: this.getDifficulty(),
			questionTypes: this.getQuestionTypes(),
            allQuestionTypes: $('#questionType').val() != 'SelectQuestionTypes'
		};

        if (options.numberOfQuestions == null || options.numberOfQuestions == '0') {
            appLib.alert('No questions match the selected filters');
            return;
        }

        if (oe.selectedExamId == null) {
            appLib.alert('There is no selected exam!');
            return;
        }

        if (options.questionTypes.length == 0) {
            appLib.alert('Select at least one question type!');
            return;
        }



        if (options.revisionType == 'PastPaper') {
            //##TODO: Add support for past papers

            //oe.questionBank = pastPaperQuestions;
            //app.trigger('startQuestions', false, true);
        }
        else if (options.revisionType == 'WorkSmart') {
			options = _.extend(options, {
				categories: this.getCategories(),
				categoriesCSV: this.getCategoriesCSV(),
				showAnswers: ($('#showAnswerAfterQuestion').val() == 'true'),
				questionStatus: this.getQuestionStatus()
			});
			
            //## Download work smart questions
            oe.workSmart(
				function () {
					oe.setRevisionOptions(options);
					
					appLib.track('work-smart-' + options.numberOfQuestions);
					app.trigger('startQuestions', options.showAnswers, false);
				},
				options.questionStatus,
				options.difficulty.minDiff,
				options.difficulty.maxDiff,
				options.categories,
				options.numberOfQuestions,
				oe.selectedExamId,
				options.questionTypes
			);
        }
        else if (options.revisionType == 'WorkHard') {
            //## Download work hard questions
            oe.workHard(
				function () {
					oe.setRevisionOptions(options);
					
					appLib.track('work-hard-' + options.numberOfQuestions);

					//## Start questions if download is successful
					app.trigger('startQuestions', true, false);
				},
				options.numberOfQuestions,
				options.questionTypes
			);
        }
    },

	
	
	//## Question Types    

    renderQuestionTypeList: function (questionTypes) {
        $('#questionTypeList').empty().append('<legend>Types:</legend>');

        var count = 1;
        _.each(questionTypes, function (type) {
            $('#questionTypeList').append('<input type="checkbox" data-theme="e" id="type' + count + '" value="' + type.QuestionType + '" />'
											  + '<label for="type' + count + '">' + type.ExamSpecificName + '</label>');
            count++;
        });

        $("#questionTypeList input[type='checkbox']").checkboxradio();				
    },

    updateQuestionTypes: function() {
        this.showQuestionTypes();
        this.updateQuestionCount();
    },

    showQuestionTypes: function () {            
        if ($('#questionType').val() == 'SelectQuestionTypes') {
            $('#questionTypeSection').show();
            //-- REFRESH CONTROL & PAGE TO CORRECTLY APPLY STYLING 
            $("#questionTypeList").controlgroup("refresh");
            $('#RevisionTypeTemplate').trigger('create');               // Is this needed?
        }
        else {
            $('#questionTypeSection').hide();
		}					
    },
    	
	setQuestionTypes: function(questionTypes) {				
		if(questionTypes == null) {
			return;
		}
															
        $('#questionType').val('SelectQuestionTypes').selectmenu('refresh');
		this.showQuestionTypes();
		
		_.each(questionTypes, function(qtype) { 
			$("#questionTypeList input[type=checkbox][value='" + qtype + "']").prop('checked', true).checkboxradio("refresh");
		});
	},

    getQuestionTypes: function () {
        var selected;

        if ($('#questionType').val() != 'SelectQuestionTypes') {
            //## API v1.1 supported sending empty array to request all question types for work hard.
            //## API v1.1.1 requires question types to be specified for work hard.
            selected = $("#questionTypeList input");
        } else {
            selected = $("#questionTypeList input:checked");
			
			//## If no types are selected then return all valid question types
			if(selected.length == 0)
				selected = $("#questionTypeList input");
        }

        var types = _.map(selected, function (item) {
            return $(item).val();
        });

        return types;
    },
		
		
	
	//## Categories
		
	//## Generate and render HTML for category list for current exam
	renderCategoryList: function (categories) {
        $('#questionCategoryList').empty().append('<legend></legend>');

        var count = 1;
        _.each(categories, function (cat) {
            $('#questionCategoryList').append('<input type="checkbox" data-theme="e" id="cat' + count + '" value="' + cat.value + '" />'
											  + '<label for="cat' + count + '">' + cat.key + '</label>');
            count++;
        });

        $("#questionCategoryList input[type='checkbox']").checkboxradio();
    },
	
	//## Update question category view  
	showQuestionCategories: function () {
        if ($('#questionCategory').val() == 'SelectCategories') {
            $('#questionCategorySection').show();
            //-- REFRESH CONTROL & PAGE TO CORRECTLY APPLY STYLING 
            $("#questionCategoryList").controlgroup("refresh");
            $('#RevisionTypeTemplate').trigger('create');
        }
        else
            $('#questionCategorySection').hide();
    },
	
	//## Get array of individual curriculum ids associated to the selected categories - e.g. [1, 2, 3]
	getCategories: function () {
        if ($('#questionCategory').val() != 'SelectCategories')
            return null;

        var selected = $("#questionCategoryList input:checked");

        var categories = [];
        _.each(selected, function (item) {
            var ids = $(item).val();

            _.each(ids.split(','), function (id) {
                categories.push({ CurriculumID: id });
            });
        });

        return categories;
    },
	
	//## Get array of curriculum ids associated to the selected categories - e.g. ['1,2', '3', '6,7,10']
	getCategoriesCSV: function () {
        if ($('#questionCategory').val() != 'SelectCategories')
            return null;

        var selected = $("#questionCategoryList input:checked");

        var categoriesCSV = [];
        _.each(selected, function (item) {            
			categoriesCSV.push($(item).val());            
        });

        return categoriesCSV;
    },
	
	//## Set selected categories by curriculum ids - e.g. ['1,2', '3', '6,7,10'] -> ENT, Eyes, Genetics
	setCategoriesCSV: function(categoriesCSV) {
		if(categoriesCSV == null) {
			return;
		}
					
        $('#questionCategory').val('SelectCategories').selectmenu('refresh');
		this.showQuestionCategories();        
		
		_.each(categoriesCSV, function(cat) { 
			$("#questionCategoryList input[type=checkbox][value='" + cat + "']").prop('checked', true).checkboxradio("refresh");
		})
    },
	
	//## Select all category checkboxes
	selectAllCats: function() {
        $("#questionCategoryList input[type='checkbox']").each(function() {
            this.checked = true;
        }).checkboxradio('refresh');
        
        this.updateWorkSmartQuestionCount();
    },
    
	//## Select no category checkboxes	
    selectNoCats: function() {
        $("#questionCategoryList input[type='checkbox']").each(function() {
            this.checked = false;
        }).checkboxradio('refresh');
        
        this.updateWorkSmartQuestionCount();
    },
	
	
	
	
	
	//## Revision Type

    changeRevisionType: function (skipQuestionCountUpdate) {
        var revisionType = $('#revisionType').val();

        if (revisionType == 'PastPaper') {
            $('#workSmartGroup').hide();
            $('#pastPaperGroup').show();
        }
        else if (revisionType == 'WorkSmart') {
            $('#pastPaperGroup').hide();
			$('#workHardStatus').hide();
            $('#workSmartGroup').show();			

            if(!skipQuestionCountUpdate)
                this.updateWorkSmartQuestionCount();
        }
        else if (revisionType == 'WorkHard') {
            $('#pastPaperGroup').hide();
            $('#workSmartGroup').hide();
			$('#workHardStatus').show();

            var options = [
                { id: 10, text: '10' },
                { id: 20, text: '20' },
                { id: 30, text: '30' },
                { id: 40, text: '40' },
                { id: 50, text: '50' },
                { id: 60, text: '60' },
                { id: 70, text: '70' },
                { id: 80, text: '80' },
                { id: 90, text: '90' },
                { id: 100, text: '100' }
            ];
            appLib.fillDropDown('questionLimit', options, '', ' questions');
        }
    },



	//## Question Status

    changeQuestionStatus: function () {
        this.updateWorkSmartQuestionCount();
    },

	
	
	//## Question Counts

    updateQuestionCount: function () {
        var revisionType = $('#revisionType').val();

        if (revisionType == 'WorkSmart') {
            this.updateWorkSmartQuestionCount();
        } else if (revisionType == 'WorkHard') {
            this.updateWorkHardQuestionCount();			
        }
    },

    updateWorkSmartQuestionCount: function () {
        var diff = this.getDifficulty();
        var categories = this.getCategories();
        var questionTypes = this.getQuestionTypes();

        if (oe.selectedExamId == null) {
            appLib.alert('There is no selected exam!');
            return;
        }

        //## Populate ddlb with options from 10 to 100 or less if there are fewer questions
        oe.workSmartQuestionCount(
			function (questionCount) {
				var options = [];
				var limit = Math.min(questionCount, 100);

				for (var i = 10; i <= limit; i += 10)
					options.push({ id: i, text: i });

				//## Add the total number of questions if less than 100, but not divisible by 10 (as it'll be a duplicate)
				if (limit < 100 && limit % 10 > 0)
					options.push({ id: questionCount, text: questionCount });

				//## If there are no questions then add a zero questions option
				if (options.length == 0)
					options.push({ id: 0, text: 0 });

				appLib.fillDropDown('questionLimit', options, '', ' questions');
			},
			this.getQuestionStatus(),
			diff.minDiff,
			diff.maxDiff,
			categories,
			oe.selectedExamId,
			questionTypes
		);
    },
		
	updateWorkHardQuestionCount: function() {
		$.proxy(
			oe.getWorkHardStatus, 
			this, 
			function(questionsAnswered, totalQuestions) {
				var pct = Math.floor((questionsAnswered / totalQuestions) * 100, 0) + '%';
			
				$('#workHardStatus .progress-bar-inner').css('width', pct);					
                $('#workHardStatus .progress-text').text(questionsAnswered + ' of ' + totalQuestions + ' answered (' + pct + ' complete)');                    
			},
			this.getQuestionTypes()
		).apply();		
	},

	
	
	//## Question Difficulty

    isDifficultySliderVisible: function () {
        return $('#questionDifficulty').val() == 'SelectDifficulty';
    },

    showQuestionDifficulty: function (e) {
        var questionDifficulty = $('#questionDifficulty').val();

        if (questionDifficulty == 'AllQuestions')
            $('#difficultySliderGroup').hide();
        else if (questionDifficulty == 'SelectDifficulty')
            $('#difficultySliderGroup').show();
    },

    getDifficulty: function () {
        var minDiff = 0.01, maxDiff = 0.99, diffVal = -1;

        if (this.isDifficultySliderVisible()) {
            diffVal = parseInt($('#questionDifficultyValue').val());

            minDiff = (diffVal - 1) / 10;
            maxDiff = (diffVal + 1) / 10;

            if (minDiff <= 0)
                minDiff = 0.01;

            if (maxDiff >= 1)
                maxDiff = 0.99;
        }

        return {
            minDiff: minDiff,
            maxDiff: maxDiff,
			diff: diffVal
        };
    },

	setDifficulty: function (diff) {
        if(diff == -1)
			return;

		
		$('#questionDifficulty').val('SelectDifficulty').selectmenu('refresh');
		$('#questionDifficultyValue').val(diff).slider('refresh');;
		this.showQuestionDifficulty();		       
    },
	
	
	
	//## Question Status
	
    getQuestionStatus: function () {
        var status = $('#questionStatus').val();

        if (status == 'NotSeen')
            return oe.workSmartQuestionType.NotSeenBefore;
        else if (status == 'AllQuestions')
            return oe.workSmartQuestionType.AllQuestions;
        else if (status == 'WrongQuestions')
            return oe.workSmartQuestionType.WrongBefore;
        else if (status == 'TaggedQuestions')
            return oe.workSmartQuestionType.Tagged;
    },
	
	setQuestionStatus: function (status) {
        var val = ''; 
        
        if (status == oe.workSmartQuestionType.NotSeenBefore)
			val = 'NotSeen';        
        else if (status == oe.workSmartQuestionType.AllQuestions)
			val = 'AllQuestions';        
        else if (status == oe.workSmartQuestionType.WrongBefore)
			val = 'WrongQuestions';        
        else if (status == oe.workSmartQuestionType.Tagged)
			val = 'TaggedQuestions';			
		
		$('#questionStatus').val(val).selectmenu('refresh');
    },
	
	
	//## Reset filters
	
	resetFilters: function() {
		appLib.confirm('Are you sure you want to reset your revision filters?',
					   function (index) {
					       if (index == 1) {
					           oe.clearRevisionOptions();
							   app.trigger('reloadRevisionType');
						   }
					   },
					   'Reset Filters?',
					   'Yes,No');
	}
});



//========================================================================================

//## BoF View
var QuestionBrowserView = Backbone.View.extend({
    template: _.template(oeTemplate.get('QuestionBrowserTemplate')),
    optionTemplate: _.template(oeTemplate.get('QuestionOptionTemplate')),

    render: function (eventName) {
        var optionHtml = this.buildHtmlForOptions(this.model.get('options'));

        //## Used for question index and count
        var session = oe.currentSession();

        //## _.extend() copies right object properties into left object 
        var completeModel = _.extend(this.model.toJSON(),
									{
									    optionHtml: optionHtml,
									    questionIndex: session.get('questionIndex') + 1,
									    questionCount: oe.questionBank.length,
									    selectText: '(Please select 1 option)',
										reviewButtonStyle: (session.get('answers').length > 0 ? '' : 'display:none;')
									});


        //## Render the templated HTML
        $(this.el).html(this.template(completeModel));
				
        //## Delay until view is rendered then update radio state after each radio state change
        _.delay(function() {
            $(document).on('change', 'input[type=radio]', function(e) {				
                $('input[type=radio]').checkboxradio('refresh');				
            });
        }, 1000, this);				
		
        return this;
    },


    //## Returns HTML for a radio list of options
    buildHtmlForOptions: function (options) {
        if (_.isUndefined(options) || options.length == 0)
            return '';


        var template = this.optionTemplate;
        var optionHtml = '';

        //## Process question options
        options.each(function (option) {
            optionHtml += template(option.toJSON());
        });

        return optionHtml;
    },



    events: {
        "click #answer-button": "answerQuestion",
        "click #session-review-button": "sessionReview"
    },

    answerQuestion: function () {
        var selection = $('#optionList').find('input[type=radio]:checked');

        //## Ensure an answer has been selected
        if (selection.length != 1) {
            appLib.alert('Please select one option.');
            return;
        }

        //## Store the user's answer
        var answerId = parseInt(selection.val());
        this.model.answerQuestion(answerId);
    },

    //## TODO: Refactor into a shared function or parent view?
    sessionReview: function () {
        appLib.confirm('Are you sure you want to finish this question session?',
					   function (index) {
					       if (index == 1)
					           app.trigger("viewSessionResults");
					   },
					   'Finish Questions?',
					   'Yes,No');
    }
});




//## BoF Answer
var QuestionBrowserAnswerView = Backbone.View.extend({
    template: _.template(oeTemplate.get('QuestionBrowserAnsweredTemplate')),
    disabledOptionTemplate: _.template(oeTemplate.get('DisabledQuestionOptionTemplate')),

    initialize: function() {        
        AnswerViewMixin.addCommonEvents(this);
    },

    render: function (eventName) {
        var answer = this.model.get('lastAnswer');
        var optionHtml = this.buildHtmlForOptions(this.model.get('options'), answer.get('answerId'));

        //appLib.log('Comment: ' + this.model.get('comment'));

        //## Used for question index and count
        var session = oe.currentSession();

		var showFinish = session.allQuestionsAnswered() && session.hasAnswersToUpload();

        var contentEnd = '';         
        if(!session.isCompleted() && oe.auth.uploadAnswers()) {
            contentEnd += oe.getQuestionRatingHtml(this.model.get('id'));            
            contentEnd += oe.getQuestionFeedbackHtml(this.model.get('id'));            
        }

        //## _.extend() copies right object properties into left object 
        var completeModel = _.extend(this.model.toJSON(),
									{
									    optionHtml: optionHtml,
									    resultColour: oe.resultColour(answer.get('score')),
									    result: oe.resultText(answer.get('score')),
									    questionIndex: session.get('questionIndex') + 1,
									    questionCount: oe.questionBank.length,
									    nextButtonText: (showFinish ? 'Finish' : 'Next Question'),
										nextNavButtonText: (showFinish ? 'Finish' : 'Next'),
                                        selectText: '',
										exitAnswerReviewStyle: appLib.cssDisplay(session.isCompleted()),
                                        contentEnd: contentEnd
									});        

        //## Render the templated HTML
        $(this.el).html(this.template(completeModel));        

        return this;
    },
    

    //## Returns HTML for a radio list of options
    buildHtmlForOptions: function (options, userAnswerId) {
        if (_.isUndefined(options) || options.length == 0)
            return '';


        //## Copy options so as not to modify the original when displaying correct/incorrect labels
        var localOptions = new Backbone.Collection(options.toJSON());

        var template = this.disabledOptionTemplate;
        var optionHtml = '';

        //## Process question options
        localOptions.each(function (option) {
            var selected = '';
            var text = option.get('text');

            //## Check the user's selected answer
            if (option.get('id') == userAnswerId) {
                selected = 'checked';

                if (option.get('score') == 100)
                    option.set('text', text + ' - <span class="correct">Correct</span>');
                else
                    option.set('text', text + ' - <span class="incorrect">Incorrect answer selected</span>');
            }
            else if (option.get('score') == 100)
                option.set('text', text + ' - <span class="correct">This is the correct answer</span>');


            var modelData = option.toJSON();
            optionHtml += template(_.extend(modelData, { checked: selected }));
        });

        return optionHtml;
    }    
});



//========================================================================================

//## NoM View
var NOMView = Backbone.View.extend({
    template: _.template(oeTemplate.get('QuestionBrowserTemplate')),
    optionTemplate: _.template(oeTemplate.get('OptionCheckboxTemplate')),

    render: function (eventName) {
        var optionHtml = this.buildHtmlForOptions(this.model.get('options'));

        //## Used for question index and count
        var session = oe.currentSession();

        var correctOptions = this.model.get('numberOfOptions');
        var selectText = '(Please select ' + correctOptions + ' option' + (correctOptions > 1 ? 's' : '') + ')';
        if (this.model.get('selectAllThatApply'))
            selectText = '(Please select all that apply)';


        //## _.extend() copies right object properties into left object 
        var completeModel = _.extend(this.model.toJSON(),
									{
									    optionHtml: optionHtml,
									    questionIndex: session.get('questionIndex') + 1,
									    questionCount: oe.questionBank.length,
									    selectText: selectText,
										reviewButtonStyle: (session.get('answers').length > 0 ? '' : 'display:none;')
									});


        //## Render the templated HTML
        $(this.el).html(this.template(completeModel));

		
        //## Delay until view is rendered then update checkbox state after each checkbox state change
        _.delay(function() {
            $(document).on('change', 'input[type=checkbox]', function(e) {
                $('input[type=checkbox]').checkboxradio('refresh');
            });
        }, 1000, this);
                                   
								   
        return this;
    },


    //## Returns HTML for a radio list of options
    buildHtmlForOptions: function (options) {
        if (_.isUndefined(options) || options.length == 0)
            return '';


        var template = this.optionTemplate;
        var optionHtml = '';

        //## Process question options
        options.each(function (option) {
            optionHtml += template(option.toJSON());
        });

        return optionHtml;
    },



    events: {
        "click #answer-button": "answerQuestion",
        "click #session-review-button": "sessionReview"
    },

    answerQuestion: function () {
        var selections = $('#optionList').find('input[type=checkbox]:checked');

        var requiredSelections = this.model.get('numberOfOptions');

        if (this.model.get('selectAllThatApply')) {
            //## Select all that apply
            if (selections.length == 0) {
                appLib.alert('Please select at least one option.');
                return;
            }

        } else {
            //## Select N options
            if (selections.length != requiredSelections) {
                appLib.alert('Please select ' + requiredSelections + ' options.');
                return;
            }
        }


        //## Store the user's answers
        var answers = [];

        _.each(selections, function (el) {
            answers.push(parseInt($(el).val()));
        });

        this.model.answerQuestion(answers);
    },

    sessionReview: function () {
        appLib.confirm('Are you sure you want to finish this question session?',
					   function (index) {
					       if (index == 1)
					           app.trigger("viewSessionResults");
					   },
					   'Finish Questions?',
					   'Yes,No');
    }
});




//## NoM Answer
var NOMAnsweredView = Backbone.View.extend({
    template: _.template(oeTemplate.get('QuestionBrowserAnsweredTemplate')),
    disabledOptionTemplate: _.template(oeTemplate.get('DisabledOptionCheckboxTemplate')),

    initialize: function() {        
        AnswerViewMixin.addCommonEvents(this);
    },

    render: function (eventName) {
        var answer = this.model.get('lastAnswer');
        var optionHtml = this.buildHtmlForOptions(this.model.get('options'), answer.get('answers'));

        //appLib.log('Comment: ' + this.model.get('comment'));

        //## Used for question index and count
        var session = oe.currentSession();

        var correctOptions = this.model.get('numberOfOptions');
        var selectText = '';
        if (correctOptions == 1)
            selectText = '(There was 1 correct answer)';
        else
            selectText = '(There were ' + correctOptions + ' correct answers)';

		var showFinish = session.allQuestionsAnswered() && session.hasAnswersToUpload();

        var contentEnd = '';         
        if(!session.isCompleted() && oe.auth.uploadAnswers()) {
            contentEnd += oe.getQuestionRatingHtml(this.model.get('id'));            
            contentEnd += oe.getQuestionFeedbackHtml(this.model.get('id'));            
        }

        //## _.extend() copies right object properties into left object 
        var completeModel = _.extend(this.model.toJSON(),
									{
									    optionHtml: optionHtml,
									    resultColour: oe.resultColour(answer.get('score')),
									    result: oe.resultText(answer.get('score')),
                                        questionIndex: session.get('questionIndex') + 1,
									    questionCount: oe.questionBank.length,
									    nextButtonText: (showFinish ? 'Finish' : 'Next Question'),
										nextNavButtonText: (showFinish ? 'Finish' : 'Next'),
									    selectText: selectText,
										exitAnswerReviewStyle: appLib.cssDisplay(session.isCompleted()),
                                        contentEnd: contentEnd
									});


        //## Render the templated HTML
        $(this.el).html(this.template(completeModel));
        return this;
    },


    //## Returns HTML for a radio list of options
    buildHtmlForOptions: function (options, userAnswers) {
        if (_.isUndefined(options) || options.length == 0)
            return '';


        //## Copy options so as not to modify the original when displaying correct/incorrect labels
        var localOptions = new Backbone.Collection(options.toJSON());

        var template = this.disabledOptionTemplate;
        var optionHtml = '';

        //## Process question options
        localOptions.each(function (option) {
            var selected = '';
            var text = option.get('text');

            //## Did the user select this answer?
            var selectedAnswer = _.find(userAnswers, function (answer) {
                return (answer == option.get('id'));
            });

            if (selectedAnswer != null) {
                selected = 'checked';

                if (option.get('score') == 100)
                    option.set('text', text + ' - <span class="correct">Correct</span>');
                else
                    option.set('text', text + ' - <span class="incorrect">Incorrect answer selected</span>');
            }
            else if (option.get('score') == 100)
                option.set('text', text + ' - <span class="correct">This is the correct answer</span>');


            var modelData = option.toJSON();
            optionHtml += template(_.extend(modelData, { checked: selected }));
        });

        return optionHtml;
    }
});



//========================================================================================

//## MCQ View
var MCQView = Backbone.View.extend({
    template: _.template(oeTemplate.get('MCQTemplate')),
    optionTemplate: _.template(oeTemplate.get('MCQOptionTemplate')),

    render: function (eventName) {
        var optionHtml = this.buildHtmlForOptions(this.model.get('options'));

        //## Used for question index and count
        var session = oe.currentSession();

        //## _.extend() copies right object properties into left object 
        var completeModel = _.extend(this.model.toJSON(),
									{
									    optionHtml: optionHtml,
									    questionIndex: session.get('questionIndex') + 1,
									    questionCount: oe.questionBank.length,
										reviewButtonStyle: (session.get('answers').length > 0 ? '' : 'display:none;')										
									});											

        //## Render the templated HTML
        $(this.el).html(this.template(completeModel));
		
		//## Delay until view is rendered then update checkbox state after each checkbox state change
        _.delay(function() {
            $(document).on('change', 'input[type=radio]', function(e) {
                $('input[type=radio]').checkboxradio('refresh');
				appLib.log("Refresher");
            });
        }, 1000, this);
		
        return this;
    },


    //## Returns HTML for multiple true/false radio options
    buildHtmlForOptions: function (options) {
        if (_.isUndefined(options) || options.length == 0)
            return '';


        var template = this.optionTemplate;
        var optionHtml = '';

        //## Process question options
        options.each(function (option) {
            optionHtml += template(option.toJSON());
        });

        return optionHtml;
    },



    events: {
        "click #answer-button": "answerQuestion",
        "click #session-review-button": "sessionReview"
    },

    answerQuestion: function () {
        //## Ensure all questions have been answered
        if ($('input[type=radio]:checked').length != ($('input[type=radio]').length / 2)) {
            appLib.alert('Please answer all sections.');
            return;
        }

        //## Create an array of answer IDs and values
        var answers = [];
        _.each($('input[type=radio]:checked'), function (radioEl) {
            var el = $(radioEl);

            answers.push({
                //## radioEl's name is the answerId prefixed with 'question-option-'
                id: el.attr('name').replace('question-option-', ''),
                value: (el.val() == "1")
            });
        });

        //## Store the user's answer		
        this.model.answerQuestion(answers);
    },

    sessionReview: function () {
        appLib.confirm('Are you sure you want to finish this question session?',
					   function (index) {
					       if (index == 1)
					           app.trigger("viewSessionResults");
					   },
					   'Finish Questions?',
					   'Yes,No');
    }
});


//## MCQ Answer
var MCQAnsweredView = Backbone.View.extend({
    template: _.template(oeTemplate.get('MCQAnsweredTemplate')),
    disabledOptionTemplate: _.template(oeTemplate.get('DisabledMCQOptionTemplate')),

    initialize: function() {        
        AnswerViewMixin.addCommonEvents(this);
    },

    render: function (eventName) {
        var answer = this.model.get('lastAnswer');
        var optionHtml = this.buildHtmlForOptions(this.model.get('options'), answer.get('answers'));

        //## Used for question index and count
        var session = oe.currentSession();        

		var showFinish = session.allQuestionsAnswered() && session.hasAnswersToUpload();

        var contentEnd = '';         
        if(!session.isCompleted() && oe.auth.uploadAnswers()) {
            contentEnd += oe.getQuestionRatingHtml(this.model.get('id'));            
            contentEnd += oe.getQuestionFeedbackHtml(this.model.get('id'));            
        }

        //## _.extend() copies right object properties into left object 
        var completeModel = _.extend(this.model.toJSON(),
									{
									    optionHtml: optionHtml,
									    resultColour: oe.resultColour(answer.get('score')),
									    result: oe.resultText(answer.get('score')),
                                        questionIndex: session.get('questionIndex') + 1,
									    questionCount: oe.questionBank.length,
									    nextButtonText: (showFinish ? 'Finish' : 'Next Question'),
										nextNavButtonText: (showFinish ? 'Finish' : 'Next'),
										exitAnswerReviewStyle: appLib.cssDisplay(session.isCompleted()),
                                        contentEnd: contentEnd
									});		

        //## Render the templated HTML
        $(this.el).html(this.template(completeModel));
        return this;
    },


    //## Returns HTML for a radio list of options
    buildHtmlForOptions: function (options, userAnswers) {
        if (_.isUndefined(options) || options.length == 0)
            return '';


        //## Copy options so as not to modify the original when displaying correct/incorrect labels
        var localOptions = new Backbone.Collection(options.toJSON());

        var template = this.disabledOptionTemplate;
        var optionHtml = '';

        //## Process question options
        localOptions.each(function (option) {
            var trueSelected = '';
            var falseSelected = '';
            var text = option.get('answerText');

            //## Get the user's response
            var currentAnswer = _.find(userAnswers, function (answer) {
                return (option.get('id') == answer.id);                
            });

            if (currentAnswer == null) {
                appLib.alert('Error - Could not find option id: ' + option.get('id'));
                return '';
            }


            //## Select the user's response radio button
            if (currentAnswer.value)
                trueSelected = 'checked';
            else
                falseSelected = 'checked';


            //## Display the result
            if (option.get('answer') == currentAnswer.value)
                option.set('answerText', text + ' - <span class="correct">Correct</span>');
            else
                option.set('answerText', text + ' - <span class="incorrect">Incorrect</span>');



            var modelData = option.toJSON();
            optionHtml += template(_.extend(modelData, { falseSelected: falseSelected, trueSelected: trueSelected }));
        });

        return optionHtml;
    }
});


//========================================================================================

//## EMQ View
var EMQView = Backbone.View.extend({
    template: _.template(oeTemplate.get('EMQTemplate')),
    alphabeticTemplate: _.template(oeTemplate.get('AlphabeticChoiceTemplate')),
    stemTemplate: _.template(oeTemplate.get('EMQQuestionStemTemplate')),

    render: function (eventName) {
        var choiceList = this.buildAlphabeticChoiceList(this.model.get('choices'));
        var choiceDropDownHtml = this.buildHtmlForChoices(this.model.get('choices'));

        var stemHtml = this.buildHtmlForStems(this.model.get('options'), choiceDropDownHtml);

        //## Used for question index and count
        var session = oe.currentSession();

        //## _.extend() copies right object properties into left object 
        var completeModel = _.extend(this.model.toJSON(),
									{
									    stemHtml: stemHtml,
									    questionIndex: session.get('questionIndex') + 1,
									    questionCount: oe.questionBank.length,
									    choiceList: choiceList,
										reviewButtonStyle: (session.get('answers').length > 0 ? '' : 'display:none;')
									});


        //## Render the templated HTML
        $(this.el).html(this.template(completeModel));
        return this;
    },


    //## Returns HTML for a list of options prefixed by alphabetic chars
    buildAlphabeticChoiceList: function (choices) {
        if (_.isUndefined(choices) || choices.length == 0)
            return '';
        
        var choicesHtml = '';
        var index = 0;

        var template = this.alphabeticTemplate;

        //## Process choices
        choices.each(function (choice) {		
            choicesHtml += template(_.extend(choice.toJSON(), { letter: oeConstants.alpha[index] }));
            index++;
        });

        return choicesHtml;
    },


    //## Returns HTML for drop down list of choices
    buildHtmlForChoices: function (choices) {
        if (_.isUndefined(choices) || choices.length == 0)
            return '';

        var choicesHtml = '';

        //## Process choices
        choices.each(function (choice) {
            choicesHtml += '<option value="' + choice.get('id') + '" id="' + choice.get('id') + '">' + choice.get('text') + '</option>';
        });

        return choicesHtml;
    },


    //## Returns HTML for all question stems
    buildHtmlForStems: function (stems, choiceHtml) {
        if (_.isUndefined(stems) || stems.length == 0)
            return '';


        var template = this.stemTemplate;
        var stemHtml = '';

        //## Process stems
        stems.each(function (stem) {
			var isAdditionalAnswer = (stem.get('text') == oeConstants.emqAdditionalAnswer);
			var style = (isAdditionalAnswer ? 'display:none;' : '');		
			
            stemHtml += template(_.extend(stem.toJSON(), { 
				choiceHtml: choiceHtml, 
				style: style,
				isAdditionalAnswer: (isAdditionalAnswer ? '1' : '0') 
			}));			
			
			//## Padding between the pair of answers
			if(isAdditionalAnswer)
				stemHtml += "<div style='padding-bottom:20px;'></div>";
        });

        return stemHtml;
    },



    events: {
        "click #answer-button": "answerQuestion",
        "click #session-review-button": "sessionReview"
    },

    answerQuestion: function () {
        //## Ensure all questions have been answered
		var error = '';
        var answers = [];		
		var lastValue = null;
		
        $('select').each(function (index, element) {
            var el = $(element);

            if (el.val() == -1) {
                error = 'Please answer section ' + (index + 1);
                return false;
            } else if(el.data('additional-answer') == '1' && el.val() == lastValue) {
				error = 'Section ' + index + ' and ' + (index + 1) + ' cannot have the same answer';
                return false;
			}			

			//## Track last answer value for comparison in EMI questions
			lastValue = el.val();
			
            answers.push({ 
                //## select id is prefixed with 'stem-'
                itemId: parseInt(el.attr('id').replace('stem-', ''), 10),
                answerOptionId: parseInt(el.val(), 10)
            });
        });

        if (error.length > 0) {
            appLib.alert(error);
            return;
        }


        //## Store the user's answer		
        this.model.answerQuestion(answers);
    },


    //## Could be moved into a base class
    sessionReview: function () {
        appLib.confirm('Are you sure you want to finish this question session?',
					   function (index) {
					       if (index == 1)
					           app.trigger("viewSessionResults");
					   },
					   'Finish Questions?',
					   'Yes,No');
    }
});


//## EMQ Answer
var EMQAnsweredView = Backbone.View.extend({
    template: _.template(oeTemplate.get('EMQAnsweredTemplate')),
    alphabeticTemplate: _.template(oeTemplate.get('AlphabeticChoiceTemplate')),
    stemTemplate: _.template(oeTemplate.get('EMQAnsweredQuestionStemTemplate')),

    initialize: function() {        
        AnswerViewMixin.addCommonEvents(this);
    },

    render: function (eventName) {
        var answer = this.model.get('lastAnswer');
        var choiceList = this.buildAlphabeticChoiceList(this.model.get('choices'));
        var stemHtml = this.buildHtmlForStems(this.model.get('options'), this.model.get('choices'), answer.get('answers'));

        //## Used for question index and count
        var session = oe.currentSession();
        
		var showFinish = session.allQuestionsAnswered() && session.hasAnswersToUpload();

        var contentEnd = '';         
        if(!session.isCompleted() && oe.auth.uploadAnswers()) {
            contentEnd += oe.getQuestionRatingHtml(this.model.get('id'));            
            contentEnd += oe.getQuestionFeedbackHtml(this.model.get('id'));            
        }

        //## _.extend() copies right object properties into left object 
        var completeModel = _.extend(this.model.toJSON(),
									{
									    stemHtml: stemHtml,
									    questionIndex: session.get('questionIndex') + 1,
									    questionCount: oe.questionBank.length,
                                        nextButtonText: (showFinish ? 'Finish' : 'Next Question'),
										nextNavButtonText: (showFinish ? 'Finish' : 'Next'),
									    choiceList: choiceList,
									    resultColour: oe.resultColour(answer.get('score')),
									    result: oe.resultText(answer.get('score')),
										exitAnswerReviewStyle: appLib.cssDisplay(session.isCompleted()),
                                        contentEnd: contentEnd
									});


        //## Render the templated HTML
        $(this.el).html(this.template(completeModel));
        return this;
    },


    //## Returns HTML for a list of options prefixed by alphabetic chars
    buildAlphabeticChoiceList: function (choices) {
        if (_.isUndefined(choices) || choices.length == 0)
            return '';
        
        var choicesHtml = '';
        var index = 0;

        var template = this.alphabeticTemplate;

        //## Process choices
        choices.each(function (choice) {
            choicesHtml += template(_.extend(choice.toJSON(), { letter: oeConstants.alpha[index] }));
            index++;
        });

        return choicesHtml;
    },


    //## Returns HTML for drop down list of choices
    buildHtmlForChoice: function (choice) {
        return '<option value="' + choice.get('id') + '" id="' + choice.get('id') + '">' + choice.get('text') + '</option>';
    },


    //## Returns HTML for all question stems
    buildHtmlForStems: function (stems, choices, answers) {
        if (_.isUndefined(stems) || stems.length == 0
            || _.isUndefined(choices) || choices.length == 0
            || _.isUndefined(answers) || answers.length == 0)
            return '';


        var template = this.stemTemplate;
        var buildHtmlForChoice = this.buildHtmlForChoice;
        var stemHtml = '';


        //## Process stems
        stems.each(function (stem) {
            //## Get the answer for this stem
            var userAnswer = _.find(answers, function (answer) {
                return (answer.itemId == stem.get('id'));
            });

            if(userAnswer == null)
                return;


            //## Get the choice for this answerId
            //## [Different syntax as it's a Backbone collection]
            var choice = choices.find(function (choice) {
                return (choice.get('id') == userAnswer.answerOptionId);
            });
			
			var correctChoice = choices.find(function(choice) {
				return (choice.get('id') == stem.get('answerId'));
			});

            if(choice == null)
                return;

            var result;
			var correctAnswerText; 
            if (userAnswer != null && userAnswer.answerOptionId == stem.get('answerId')) {
                result = '<div class="emqAnswerCorrect marginTop"><h4 class="green emqAnswer"><span class="emqHeadingBG">Correct</span></h4>';
				correctAnswerText = '<p class="emqStemCorrect"></p>';
			}			
			else {
                result = '<div class="emqAnswerWrong marginTop"><h4 class="red emqAnswer"><span class="emqHeadingBG">Incorrect</span></h4>';
				correctAnswerText = '<p class="emqStemWrong">The correct answer is: ' + correctChoice.get('text') + '</p>';
			}
			
			var style = (stem.get('text') == oeConstants.emqAdditionalAnswer ? 'visibility:hidden; height:0px;' : '');
			
            stemHtml += template(_.extend(stem.toJSON(), { 
                choiceHtml: buildHtmlForChoice(choice),
                result: result,
				correctAnswerText: correctAnswerText,
				style: style
            }));
			
			//## Padding between the pair of answers
			if(style != '')
				stemHtml += "<div style='padding-bottom:50px;'></div>";
        });

        return stemHtml;    
    }

});





//========================================================================================

//## SJQ View
var SJQView = Backbone.View.extend({
    template: _.template(oeTemplate.get('SJQTemplate')),
    optionTemplate: _.template(oeTemplate.get('SJQOptionTemplate')),

    render: function (eventName) {
        var options = this.model.get('options');
        var optionHtml = this.buildHtmlForOptions(options);

        //## Used for question index and count
        var session = oe.currentSession();

        var selectionInfo = '(Please rank the options from 1 to ' + options.length + ' where 1 is the best and ' + options.length + ' is the worst)';

        //## _.extend() copies right object properties into left object 
        var completeModel = _.extend(this.model.toJSON(),
									{
									    optionHtml: optionHtml,
									    questionIndex: session.get('questionIndex') + 1,
									    questionCount: oe.questionBank.length,
                                        selectionInfo: selectionInfo,
										reviewButtonStyle: (session.get('answers').length > 0 ? '' : 'display:none;')
									});


        //## Render the templated HTML
        $(this.el).html(this.template(completeModel));
        return this;
    },


    //## Returns HTML for options with a textbox for rank
    buildHtmlForOptions: function (options) {
        if (_.isUndefined(options) || options.length == 0)
            return '';


        var template = this.optionTemplate;
        var optionHtml = '';

        //## Process question options
        options.each(function (option) {
            optionHtml += template(option.toJSON());
        });

        return optionHtml;
    },



    events: {
        "click #answer-button": "answerQuestion",
        "click #session-review-button": "sessionReview"
    },

    answerQuestion: function () {
        //## Ensure all options have been answered
        var answers = [];
        var ranks = [];
        var maxRank = this.model.get('options').length;

        $('input[type=number]').each(function (index, txt) {
            var el = $(txt);
            var val = el.val();
            var errorPrefix = 'Option ' + (index + 1);

            if (val.length < 1) {
                appLib.alert(errorPrefix + ' cannot be empty');
                return false;
            } else if (!appLib.isInt(val)) {
                appLib.alert(errorPrefix + ' is not an integer');
                return false;
            }

            var rank = parseInt(val, 10);
            if (rank < 1 || rank > maxRank) {
                appLib.alert(rank + ' is out of the range of 1 to ' + maxRank);
                return false;
            } else if (_.indexOf(ranks, rank) > -1) {
                appLib.alert('You have entered ' + rank + ' more than once. Please only use each number once');
                return false;
            }

            //## Store the rank and the answer
            ranks.push(rank);
            answers.push({
                //## textbox's id is the answerId prefixed with 'question-option-'
                id: parseInt(el.attr('id').replace('question-option-', ''), 10),
                rank: rank
            });
        });

        if (ranks.length != maxRank)
            return;


        //## Store the user's answer		
        this.model.answerQuestion(answers);
    },

    sessionReview: function () {
        appLib.confirm('Are you sure you want to finish this question session?',
					   function (index) {
					       if (index == 1)
					           app.trigger("viewSessionResults");
					   },
					   'Finish Questions?',
					   'Yes,No');
    }
});




//## SJQ Answer
var SJQAnsweredView = Backbone.View.extend({
    template: _.template(oeTemplate.get('SJQAnsweredTemplate')),
    disabledOptionTemplate: _.template(oeTemplate.get('AnsweredSJQOptionTemplate')),

    initialize: function() {        
        AnswerViewMixin.addCommonEvents(this);
    },

    render: function (eventName) {
        var answer = this.model.get('lastAnswer');
        var userChoicesHtml = this.buildHtmlForUserAnswers(this.model.get('options'), answer.get('answers'));
        var correctChoicesHtml = this.buildHtmlForCorrectAnswers(this.model.get('options'));

        //## Used for question index and count
        var session = oe.currentSession();

		var showFinish = session.allQuestionsAnswered() && session.hasAnswersToUpload();

        var contentEnd = '';         
        if(!session.isCompleted() && oe.auth.uploadAnswers()) {
            contentEnd += oe.getQuestionRatingHtml(this.model.get('id'));            
            contentEnd += oe.getQuestionFeedbackHtml(this.model.get('id'));            
        }
		
        //## _.extend() copies right object properties into left object 
        var completeModel = _.extend(this.model.toJSON(),
									{
									    userChoicesHtml: userChoicesHtml,
									    correctChoicesHtml: correctChoicesHtml,
									    resultColour: oe.resultColour(answer.get('score')),
									    result: oe.resultText(answer.get('score')),
									    questionIndex: session.get('questionIndex') + 1,
									    questionCount: oe.questionBank.length,
									    nextButtonText: (showFinish ? 'Finish' : 'Next Question'),
										nextNavButtonText: (showFinish ? 'Finish' : 'Next'),
										exitAnswerReviewStyle: appLib.cssDisplay(session.isCompleted()),
                                        contentEnd: contentEnd
									});


        //## Render the templated HTML
        $(this.el).html(this.template(completeModel));
        return this;
    },


    buildHtmlForUserAnswers: function (options, userAnswers) {
        var template = this.disabledOptionTemplate;
        var optionHtml = '';

        //## Sort user answers by rank
        var rankedAnswers = _.sortBy(userAnswers, function (answer) {
            return answer.rank;
        });


        //## Process each answer
        _.each(rankedAnswers, function (answer) {
            //## Find the text for this answer
            var option = options.find(function (option) {
                return (answer.id == option.get('id'));
            });

            var modelData = option.toJSON();
            optionHtml += template(_.extend(modelData, {}));
        });

        return optionHtml;
    },


    //## Returns HTML for a list of correct answers
    buildHtmlForCorrectAnswers: function (options) {
        if (_.isUndefined(options) || options.length == 0)
            return '';


        //## Copy options so as not to modify the original when displaying correct/incorrect labels
        var localOptions = new Backbone.Collection(options.toJSON());

        var template = this.disabledOptionTemplate;
        var optionHtml = '';

        //## Sort question options by rank
        var rankedOptions = localOptions.sortBy(function (option) {
            return option.get('rank');
        });


        _.each(rankedOptions, function (option) {
            var modelData = option.toJSON();
            optionHtml += template(_.extend(modelData, {}));
        });

        return optionHtml;
    }
});


//========================================================================================


//## Session Review
var SessionReviewView = Backbone.View.extend({
    template: _.template(oeTemplate.get('SessionReviewTemplate')),

    render: function (eventName) {
        var answered = this.model.questionsAnswered();        
        var pct = Math.round(this.model.score());

        if (answered == 0)
            pct = '?';

        //## Render the templated HTML
        $(this.el).html(this.template({
            questionsAnswered: answered,
            questionsCorrect: this.model.correctAnswers(),
            percentCorrect: pct            
        }));

        var _this = this;
        _.delay(function() {
            _this.uploadAnswers.call(_this);
        }, 100);

        return this;
    },

    events: {
        "click #uploadAnswersButton": "uploadAnswers",
		"click #reviewSession": "reviewSession"
    },


    uploadAnswers: function () {        
        this.renderGraph();

        var ratingsToUpload = oe.getQuestionRatingsToUpload();
        $('#reviewStatus').html('Uploading ratings... <img src="css/images/loader.gif" id="uploadingAnswers" />');

        
        // Could be made async, but easier for now just to do them sync        
        var _this = this;
        return new Promise(oe.getUploadQuestionRatingsPromise(ratingsToUpload))
            .then(function() {       
                var feedback = oe.getQuestionFeedbackToUpload();
                $('#reviewStatus').html('Uploading question feedback... <img src="css/images/loader.gif" id="uploadingAnswers" />');                

                return new Promise(oe.getUploadQuestionFeedbackPromise(feedback).bind(_this));
            }).then(function() {
                return new Promise(_this.uploadAnswersAjaxPromise.bind(_this));
            }).catch(function(msg) {                 
                _this.uploadError(null, msg, msg);
            });

        //## Simpler than...?
        /*
        return new Promise(oe.getUploadQuestionRatingsPromise(ratingsToUpload))
                .then(function () {
                    return new Promise(this.uploadAnswersAjaxPromise.bind(this));
                }.bind(this))
                .catch(function (msg) {                    
                    this.uploadError(null, msg, msg);
                }.bind(this));
        */
    },

    renderGraph: function() {
        var correct = this.model.correctAnswers();
        var incorrect = this.model.wrongAnswers();
        var partial = this.model.questionsAnswered() - (correct + incorrect);

        //## Draw graph
        var pieData = [
            { label: "Correct", color: "rgba(105,190,40,1)", data: correct },
            { label: "Incorrect", color: "rgba(205,32,44,1)", data: incorrect },
            { label: "Partially Correct", color: "rgba(240,171,0,1)", data: partial }
        ];

        var pieOptions = {
            series: {
                pie: {
                    innerRadius: 0,
                    show: true
                }
            }
        };

        $.plot($("#livePie"), pieData, pieOptions);
    },
    
    uploadAnswersAjaxPromise: function (resolve, reject) {        
        var answersToUpload = oe.getAnswersToUpload();
        
        //## Only upload answers if we have some that haven't been uploaded!
        if (answersToUpload == null) {
            appLib.log(this);
            this.showHomeButton();            
            this.showKeyLearningPoints(oe.keyLearningPoints);			

            return resolve();
        } else if(!oe.auth.uploadAnswers()) {
			//## Demo mode - fake a successful upload
            this.uploadSuccessful({ d: { ErrorMessage: null, KeyLearningPoints: null } });

            return resolve();
        }

        $('#reviewStatus').html('Uploading answers... <img src="css/images/loader.gif" id="uploadingAnswers" />');

        return oe.ajax(answersToUpload.serviceName,
            answersToUpload,
            function(data) {
                this.uploadSuccessful(data);
                return resolve();
            },
            function(xhr, msg, err) {
                this.uploadError(xhr, msg, err);
                return reject(msg);
            },
            this,
            false);
    },

    //## Fires if answers are successfully uploaded
    uploadSuccessful: function (data) {
        appLib.log('Upload successful');
        appLib.log(data);

        if (!_.isUndefined(data.d.ErrorMessage) && data.d.ErrorMessage != null && data.d.ErrorMessage.length > 0) {
            appLib.log('API returned warning message');
            this.uploadError(null, '', data.d.ErrorMessage);
            return;
        }

		var keyLearningPoints = null;
		
		if(!_.isUndefined(data.d.KeyLearningPoints) && data.d.KeyLearningPoints != null && data.d.KeyLearningPoints.length > 0) {			
			keyLearningPoints = data.d.KeyLearningPoints;
		}
		
        oe.markAnswersAsUploaded(keyLearningPoints);		
		
		//## Ready for answer review
		oe.removeUnansweredQuestions();		
        oe.save();

        this.showHomeButton();
		this.showKeyLearningPoints(keyLearningPoints);
    },

    //## Fires if an error occurs during answer upload
    uploadError: function (xhr, msg, err) {
        appLib.log(err);
        appLib.log(xhr);

        if (err != null && err.indexOf('Invalid token') >= 0) {
            appLib.alert('Your session has expired. Please login again.', function () { app.trigger('loginRequired', 'viewSessionResults'); });
            appLib.track('upload-answers-session-expired');
            return;
        }


        $('#reviewStatus').html('Unable to upload answers, please try again.');
        $('#uploadAnswersButton').show();

        
        //## Report error to GA
        var errorTrack = 'upload-answers-error';
        if(xhr != null && !_.isUndefined(xhr.status) && xhr.status != null)
            errorTrack += '-' + xhr.status;
        appLib.track(errorTrack);


        //## Inform user of error info
        if(err.indexOf('error') >= 0)
            appLib.alert(err);
    },

    showHomeButton: function () {
        $('#reviewStatus').html('Session complete');
        $('#reviewMainMenuButton').show();
        $('#uploadAnswersButton').hide();
    },
	
	showKeyLearningPoints: function(points) {				
		if(points == null || points.length == 0) {			
			return;
		}
		
		$('#keyLearningPointsSection').show();
		var html = '';
		
		_.each(points, function(section) {
			html += '<span style="font-weight:bold;">' + section.Title + '</span><ul style="margin-top:0px;">';
			
			_.each(section.Items, function(item) { 
				html += '<li>' + item + '</li>';
			});
			
			html += '</ul>';
		});
		
		$('#keyLearningPoints').html(html);
	},
	
	reviewSession: function() {				
		app.trigger('continueQuestions', 0);
	}
});
